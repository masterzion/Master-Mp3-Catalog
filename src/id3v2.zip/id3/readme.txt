TID3v2 & TID3v11 components
---------------------------
author: Daniel Mach
e-mail: dan.mach@centrum.cz
---------------------------

These components are FREEWARE, so use them as you will.
This software is distributed WITHOUT ANY WARRANTY.

 - use these components for handling ID3 tags
 - supported tags: v1.1, v2.3, v2.4 (v2.2 is NOT supported)
 - TSimpleID3v2 supports most important frames (it's similar to TID3v11)
 - included exaples (to understand how components work)
 - note, that DPR (Delphi) and PAS (Lazarus) example files are the same

please, send me any questions, bug reports or suggestions
in order to improve these components

this file was downloaded from:
http://danmach.3web.cz/downloads/components/id3.tgz
